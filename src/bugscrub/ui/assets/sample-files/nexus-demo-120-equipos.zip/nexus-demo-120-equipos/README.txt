Nexus 120-device realistic demo package

Contents:
- inventory.xlsx: customer inventory workbook with 120 devices
- demo_bug_dataset.csv: custom dataset with representative findings from S1 to S5
- nexus-demo-120-equipos-bundle.zip: upload this file in Multi-device command bundle
- bundles/: raw uncompressed bundle folders, one per device
- manifest.csv: device manifest
- expected_summary.json: expected high-level output
- expected_bug_summary.csv: expected summary by bug
- expected_device_summary.csv: expected summary by device
- expected_pareto_quick_analysis.csv: expected pareto quick-analysis table

Recommended validation flow:
1. Load demo_bug_dataset.csv in Bug Dataset Catalog and activate it.
2. Select Platform family = Nexus.
3. Upload inventory.xlsx.
4. Upload nexus-demo-120-equipos-bundle.zip.
5. Run the analysis and compare the UI/export outputs against expected_summary.json.

Generated devices: 120
Bug findings: 280
Devices with bugs: 110
Unique bugs: 11
Top risk device: N9K-LEAF-A-01
Severity counts: {"S4": 50, "S5": 20, "S2": 70, "S3": 90, "S1": 50}